export default function help() {
  console.log( '一个帮助函数' );
}

export function smallHelp() {
  console.log( '一个其他的帮助函数' );
}